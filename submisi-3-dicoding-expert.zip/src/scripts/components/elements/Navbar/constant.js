export const navigateLinks = [
  {
    text: 'HOME',
    link: '#',
  },
  {
    text: 'FAVORITE',
    link: '#/favorite',
  },
  {
    text: 'ABOUT US',
    link: 'https://daffarafi.netlify.app',
  },
];

export default navigateLinks;
