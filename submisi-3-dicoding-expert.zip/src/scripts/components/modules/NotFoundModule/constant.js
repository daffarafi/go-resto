export const navigateLinks = [
  {
    text: 'GO HOME',
    link: '#',
  },
  {
    text: 'CONTACT',
    link: 'https://daffarafi.netlify.app',
  },
];

export default navigateLinks;
