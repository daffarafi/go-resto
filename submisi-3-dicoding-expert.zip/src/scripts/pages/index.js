export * from './DetailPage';
export * from './FavoritePage';
export * from './HomePage';
export * from './NotFoundPage';
